"use client";

import { useState, useMemo, useCallback, useEffect } from "react";
import {
  Radar, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis,
  ResponsiveContainer, Tooltip,
} from "recharts";
import {
  Shield, TrendingUp, AlertTriangle, ChevronDown, ChevronUp,
  Eye, Ban, Search, MessageSquare, RotateCcw, Users, Clock,
  ArrowRight, Activity, Loader2, RefreshCw, Database,
} from "lucide-react";
import { useSpitfireData } from "@/lib/hooks/useSpitfireData";
import type { AxisScoreData, Signal } from "@/lib/supabase/types";

// ─── Design Tokens ───
const TEAL = "#00A39B";
const TEAL_LIGHT = "#00C4BB";
const TEAL_DARK = "#007A74";
const RED = "#E54D53";
const RED_LIGHT = "#FF6B70";

const STANCE_CONFIG: Record<string, { color: string; bg: string; icon: any; label: string }> = {
  Deepen:  { color: TEAL,      bg: "rgba(0,163,155,0.12)", icon: TrendingUp, label: "Deepen" },
  Explore: { color: TEAL_LIGHT, bg: "rgba(0,196,187,0.10)", icon: Search,     label: "Explore" },
  Monitor: { color: "#F59E0B",  bg: "rgba(245,158,11,0.10)", icon: Eye,       label: "Monitor" },
  Defend:  { color: "#F97316",  bg: "rgba(249,115,22,0.10)", icon: Shield,    label: "Defend" },
  Avoid:   { color: RED,        bg: "rgba(229,77,83,0.10)", icon: Ban,        label: "Avoid" },
};

// ─── Glass Neumorphism ───
const glass = {
  card: {
    background: "rgba(255,255,255,0.60)",
    backdropFilter: "blur(40px) saturate(1.6)",
    WebkitBackdropFilter: "blur(40px) saturate(1.6)",
    border: "1px solid rgba(255,255,255,0.70)",
    borderRadius: "20px",
    boxShadow: "10px 10px 28px rgba(0,0,0,0.06), -6px -6px 18px rgba(255,255,255,0.9), inset 0 1.5px 0 rgba(255,255,255,0.85)",
  },
  cardInner: {
    background: "rgba(255,255,255,0.40)",
    backdropFilter: "blur(14px)",
    WebkitBackdropFilter: "blur(14px)",
    border: "1px solid rgba(255,255,255,0.50)",
    borderRadius: "14px",
    boxShadow: "5px 5px 14px rgba(0,0,0,0.035), -3px -3px 10px rgba(255,255,255,0.75), inset 0 1px 0 rgba(255,255,255,0.70)",
  },
  pressed: {
    background: "rgba(236,239,243,0.55)",
    borderRadius: "12px",
    boxShadow: "inset 4px 4px 10px rgba(0,0,0,0.07), inset -3px -3px 8px rgba(255,255,255,0.65)",
    border: "1px solid rgba(210,215,225,0.35)",
  },
  button: {
    background: "rgba(255,255,255,0.60)",
    backdropFilter: "blur(12px)",
    WebkitBackdropFilter: "blur(12px)",
    border: "1px solid rgba(255,255,255,0.70)",
    borderRadius: "12px",
    boxShadow: "5px 5px 12px rgba(0,0,0,0.05), -3px -3px 8px rgba(255,255,255,0.85)",
    cursor: "pointer",
    transition: "all 0.2s ease",
  },
};

// ─── Flame Logo SVG ───
function SpitfireLogo({ size = 40 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 80 80" fill="none">
      <defs>
        <linearGradient id="flm" x1="40" y1="2" x2="40" y2="76" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#00D4CC"/><stop offset="40%" stopColor="#00A39B"/><stop offset="100%" stopColor="#006B66"/>
        </linearGradient>
        <filter id="ds"><feDropShadow dx="0" dy="2" stdDeviation="3" floodColor="#00A39B" floodOpacity="0.45"/></filter>
      </defs>
      <path d="M40 2C40 2,30 18,26 24C20 34,14 38,12 48C10 56,14 66,22 72C28 76,34 78,40 78C46 78,52 76,58 72C66 66,70 56,68 48C66 38,60 34,54 24C50 18,40 2,40 2Z" fill="url(#flm)" filter="url(#ds)"/>
      <path d="M22 18C22 18,18 30,16 36C14 42,14 46,16 50" stroke="url(#flm)" strokeWidth="6" fill="none" strokeLinecap="round"/>
      <path d="M58 18C58 18,62 30,64 36C66 42,66 46,64 50" stroke="url(#flm)" strokeWidth="6" fill="none" strokeLinecap="round"/>
      <ellipse cx="26.5" cy="38" rx="3" ry="1.6" fill="#004D49" transform="rotate(-8 26.5 38)"/>
      <ellipse cx="37.5" cy="38" rx="3" ry="1.6" fill="#004D49" transform="rotate(8 37.5 38)"/>
      <path d="M25 44Q28 48.5 32 48.5Q36 48.5 39 44" stroke="#004D49" strokeWidth="1.5" fill="rgba(0,92,87,0.12)" strokeLinecap="round"/>
      <path d="M26 54L28 60L30 54" fill="rgba(255,255,255,0.75)" stroke="#004D49" strokeWidth="0.8"/>
      <path d="M30 53.5L32.5 58L35 53.5" fill="rgba(255,255,255,0.65)" stroke="#004D49" strokeWidth="0.6"/>
      <path d="M40 53L42.5 57L45 53" fill="rgba(255,255,255,0.6)" stroke="#004D49" strokeWidth="0.6"/>
      <path d="M50 54L52 60L54 54" fill="rgba(255,255,255,0.75)" stroke="#004D49" strokeWidth="0.8"/>
    </svg>
  );
}

// ─── Scoring Logic (Rule-based — NOT AI) ───
function clamp(v: number, min: number, max: number) { return Math.min(max, Math.max(min, v)); }

function computeStance(scores: AxisScoreData[], weights: Record<string, number>): string {
  if (scores.length === 0) return "Monitor";
  let totalScore = 0, totalWeight = 0, controlScore = 5, internalScore = 5;
  scores.forEach(s => {
    const w = weights[s.dimensionKey] || 1.0;
    totalScore += s.finalScore * w;
    totalWeight += w;
    if (s.dimensionKey === "control_dependency") controlScore = s.finalScore;
    if (s.dimensionKey === "internal_compatibility") internalScore = s.finalScore;
  });
  const avg = totalWeight > 0 ? totalScore / totalWeight : 0;
  if (controlScore <= 3.0 && avg > 7) return "Explore";
  if (internalScore <= 2.5) return "Monitor";
  if (avg >= 7.5) return "Deepen";
  if (avg >= 6.0) return "Explore";
  if (avg >= 4.5) return "Monitor";
  if (avg >= 3.0) return "Defend";
  return "Avoid";
}

// ─── Sub-Components ───
function StanceBadge({ stance }: { stance: string }) {
  const config = STANCE_CONFIG[stance] || STANCE_CONFIG.Monitor;
  const Icon = config.icon;
  return (
    <div style={{ display: "inline-flex", alignItems: "center", gap: 10, padding: "10px 22px", background: config.bg, borderRadius: 14, border: `1.5px solid ${config.color}30` }}>
      <Icon size={20} color={config.color} strokeWidth={2.5} />
      <span style={{ color: config.color, fontWeight: 700, fontSize: 18, letterSpacing: "0.02em" }}>{config.label}</span>
    </div>
  );
}

// ★ CHANGED: AxisBar now shows weighted bar length
function AxisBar({ score, weight }: { score: AxisScoreData; weight: number }) {
  const weighted = clamp(score.finalScore * weight, 0, 10);
  const barWidth = (weighted / 10) * 100;
  const changed = Math.abs(weight - 1.0) > 0.05;
  return (
    <div style={{ padding: "10px 14px", ...glass.cardInner, marginBottom: 8 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 6 }}>
        <span style={{ fontSize: 13, fontWeight: 600, color: "#334155" }}>{score.shortName}</span>
        <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
          <span style={{ fontSize: 10, color: "#94a3b8" }}>{score.finalScore.toFixed(1)} × {weight.toFixed(1)}</span>
          <span style={{ fontSize: 15, fontWeight: 700, color: score.isRisk && weighted < 4 ? RED : changed ? TEAL : "#1e293b" }}>
            {weighted.toFixed(1)}
          </span>
        </div>
      </div>
      <div style={{ ...glass.pressed, height: 6, borderRadius: 3, overflow: "hidden", padding: 0, border: "none" }}>
        <div style={{ height: "100%", borderRadius: 3, transition: "width 0.5s ease", width: `${barWidth}%`, background: score.isRisk && weighted < 5 ? `linear-gradient(90deg, ${RED}, ${RED_LIGHT})` : `linear-gradient(90deg, ${TEAL_DARK}, ${TEAL})` }} />
      </div>
    </div>
  );
}

function SignalCard({ signal }: { signal: Signal }) {
  const pos = signal.impact_score > 0;
  return (
    <div style={{ ...glass.cardInner, padding: "12px 16px", marginBottom: 8 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 10 }}>
        <div style={{ flex: 1 }}>
          <div style={{ display: "flex", gap: 8, alignItems: "center", marginBottom: 4 }}>
            <span style={{ fontSize: 10, color: "#94a3b8", fontWeight: 500 }}>{signal.event_date}</span>
            <span style={{ fontSize: 10, fontWeight: 600, color: TEAL_DARK, padding: "1px 8px", background: "rgba(0,163,155,0.08)", borderRadius: 4 }}>{signal.event_type}</span>
            {signal.evidence_quality === "official" && <span style={{ fontSize: 9, color: TEAL, fontWeight: 600 }}>✓ Official</span>}
          </div>
          <p style={{ fontSize: 13, color: "#334155", lineHeight: 1.5, margin: 0 }}>{signal.headline}</p>
        </div>
        <div style={{ padding: "4px 10px", borderRadius: 8, minWidth: 44, textAlign: "center", background: pos ? "rgba(0,163,155,0.08)" : "rgba(229,77,83,0.08)", border: `1px solid ${pos ? TEAL : RED}20` }}>
          <span style={{ fontSize: 14, fontWeight: 700, color: pos ? TEAL : RED }}>{pos ? "+" : ""}{signal.impact_score}</span>
        </div>
      </div>
    </div>
  );
}

function SliderControl({ label, value, onChange }: { label: string; value: number; onChange: (v: number) => void }) {
  const pct = ((value - 0.3) / 1.7) * 100;
  return (
    <div style={{ marginBottom: 12 }}>
      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4 }}>
        <span style={{ fontSize: 12, fontWeight: 500, color: "#475569" }}>{label}</span>
        <span style={{ fontSize: 12, fontWeight: 700, color: TEAL }}>×{value.toFixed(1)}</span>
      </div>
      <div style={{ position: "relative", height: 24, display: "flex", alignItems: "center" }}>
        <div style={{ ...glass.pressed, width: "100%", height: 6, borderRadius: 3, position: "absolute", padding: 0, border: "none" }}>
          <div style={{ height: "100%", borderRadius: 3, width: `${pct}%`, background: `linear-gradient(90deg, ${TEAL_DARK}, ${TEAL})`, transition: "width 0.15s ease" }} />
        </div>
        <input type="range" min={0.3} max={2.0} step={0.1} value={value} onChange={e => onChange(parseFloat(e.target.value))} style={{ position: "absolute", width: "100%", height: 24, opacity: 0, cursor: "pointer", margin: 0 }} />
        <div style={{ position: "absolute", left: `calc(${pct}% - 9px)`, width: 18, height: 18, borderRadius: "50%", background: "white", border: `2.5px solid ${TEAL}`, boxShadow: "0 2px 6px rgba(0,163,155,0.3)", pointerEvents: "none", transition: "left 0.15s ease" }} />
      </div>
    </div>
  );
}

function CustomDot(props: any) {
  const { cx, cy } = props;
  if (!cx || !cy) return null;
  return <circle cx={cx} cy={cy} r={4} fill={TEAL} stroke="white" strokeWidth={2} />;
}

// ─── Stance descriptions ───
const STANCE_DESC: Record<string, string> = {
  Deepen: "총점과 리스크 지표가 모두 양호합니다. 적극적인 협력 심화를 추천합니다.",
  Explore: "잠재력은 높으나 일부 리스크 지표가 Floor에 근접합니다. 파일럿 수준의 탐색적 협력을 추천합니다.",
  Monitor: "현재 데이터로는 적극적 판단이 어렵습니다. 추가 정보 수집 후 재평가가 필요합니다.",
  Defend: "경쟁 신호가 감지되었습니다. 방어적 전략과 대안 파트너 탐색을 병행하세요.",
  Avoid: "현 시점에서 적극적 파트너십 추진은 부적절합니다.",
};
const ENG_MODEL: Record<string, string> = {
  Deepen: "Co-build / Joint GTM", Explore: "Pilot / Limited Co-sell",
  Monitor: "Information Gathering / Quarterly Review",
  Defend: "Counter-strategy / Alternative Partners", Avoid: "No Active Pursuit",
};

// ═══════════════════════════════════════════════════════════════
// MAIN DASHBOARD
// ═══════════════════════════════════════════════════════════════

export default function SPITFIREPage() {
  const { loading, error, organizations, selectedOrgId, dashboard, presets, selectOrganization, refresh } = useSpitfireData();

  const [activePreset, setActivePreset] = useState("Default");
  const [weights, setWeights] = useState<Record<string, number>>({});
  const [showSignals, setShowSignals] = useState(true);

  // Initialize weights from presets
  useEffect(() => {
    if (presets.length > 0) {
      const defaultPreset = presets.find(p => p.name === "Default");
      if (defaultPreset) {
        setWeights(defaultPreset.weights_json);
      }
    }
  }, [presets]);

  // Reset weights when company changes
  useEffect(() => {
    setActivePreset("Default");
    const defaultPreset = presets.find(p => p.name === "Default");
    if (defaultPreset) setWeights(defaultPreset.weights_json);
  }, [selectedOrgId]);

  const scores = dashboard?.scores || [];
  const signals = dashboard?.signals || [];
  const confidence = dashboard?.confidence || 0;
  const org = dashboard?.organization;

  const stance = useMemo(() => computeStance(scores, weights), [scores, weights]);
  const stanceConfig = STANCE_CONFIG[stance] || STANCE_CONFIG.Monitor;

  // ★ CHANGED: radarData now includes weights — chart reacts to slider changes
  const radarData = useMemo(() => scores.map(s => ({
    axis: s.shortName,
    score: clamp(s.finalScore * (weights[s.dimensionKey] || 1.0), 0, 10),
    fullMark: 10,
  })), [scores, weights]);

  // ★ CHANGED: weighted average score for display
  const weightedAvg = useMemo(() => {
    if (scores.length === 0) return 0;
    let ts = 0, tw = 0;
    scores.forEach(s => {
      const w = weights[s.dimensionKey] || 1;
      ts += s.finalScore * w;
      tw += w;
    });
    return tw > 0 ? ts / tw : 0;
  }, [scores, weights]);

  const handlePreset = useCallback((presetName: string) => {
    const p = presets.find(pr => pr.name === presetName);
    if (p) {
      setActivePreset(presetName);
      setWeights(p.weights_json);
    }
  }, [presets]);

  const updateWeight = useCallback((key: string, val: number) => {
    setWeights(prev => ({ ...prev, [key]: val }));
    setActivePreset("Custom");
  }, []);

  // ─── Loading State ───
  if (loading && !dashboard) {
    return (
      <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", background: "linear-gradient(135deg, #f0f2f5, #e8ecf1, #f5f7fa)", fontFamily: "'SF Pro Display', -apple-system, sans-serif" }}>
        <div style={{ ...glass.card, padding: "40px 60px", textAlign: "center" }}>
          <Loader2 size={32} color={TEAL} style={{ animation: "spin 1s linear infinite" }} />
          <p style={{ color: "#64748b", marginTop: 16, fontSize: 14 }}>Connecting to Supabase...</p>
          <style>{`@keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }`}</style>
        </div>
      </div>
    );
  }

  // ─── Error State ───
  if (error && !dashboard) {
    return (
      <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", background: "linear-gradient(135deg, #f0f2f5, #e8ecf1, #f5f7fa)", fontFamily: "'SF Pro Display', -apple-system, sans-serif" }}>
        <div style={{ ...glass.card, padding: "40px 60px", textAlign: "center", maxWidth: 500 }}>
          <Database size={32} color={RED} />
          <p style={{ color: "#1e293b", marginTop: 16, fontSize: 15, fontWeight: 600 }}>Supabase 연결 실패</p>
          <p style={{ color: "#64748b", fontSize: 13, lineHeight: 1.6 }}>{error}</p>
          <button onClick={refresh} style={{ ...glass.button, marginTop: 16, padding: "8px 20px", fontSize: 13, fontWeight: 600, color: TEAL, display: "inline-flex", alignItems: "center", gap: 6 }}>
            <RefreshCw size={14} /> 재시도
          </button>
        </div>
      </div>
    );
  }

  return (
    <div style={{
      minHeight: "100vh", padding: "20px",
      background: "linear-gradient(135deg, #f0f2f5 0%, #e8ecf1 30%, #f5f7fa 60%, #eef1f5 100%)",
      fontFamily: "'SF Pro Display', -apple-system, BlinkMacSystemFont, 'Pretendard', sans-serif",
    }}>
      {/* ─── Header ─── */}
      <div style={{ maxWidth: 1280, margin: "0 auto", marginBottom: 20 }}>
        <div style={{ ...glass.card, padding: "16px 24px", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
            <SpitfireLogo size={42} />
            <div>
              <div style={{ display: "flex", alignItems: "baseline", gap: 8 }}>
                <h1 style={{ fontSize: 18, fontWeight: 700, color: "#1e293b", margin: 0 }}>SPITFIRE</h1>
                <span style={{ fontSize: 9, fontWeight: 600, color: TEAL, background: "rgba(0,163,155,0.08)", padding: "2px 6px", borderRadius: 4 }}>PILOT v1.0</span>
                {dashboard && <span style={{ fontSize: 9, fontWeight: 600, color: TEAL, background: "rgba(0,163,155,0.08)", padding: "2px 6px", borderRadius: 4 }}>DB LIVE</span>}
              </div>
              <p style={{ fontSize: 11, color: "#94a3b8", margin: 0, fontWeight: 500 }}>Strategic Partnership Intelligence & Tactical Framework</p>
            </div>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <button onClick={refresh} style={{ ...glass.button, padding: "6px 12px", display: "flex", alignItems: "center", gap: 4, fontSize: 11, color: "#64748b", fontWeight: 500, border: "none" }}>
              <RefreshCw size={12} color="#94a3b8" /> Refresh
            </button>
            <div style={{ ...glass.pressed, padding: "6px 14px", display: "flex", alignItems: "center", gap: 6 }}>
              <Users size={13} color="#94a3b8" />
              <span style={{ fontSize: 11, color: "#64748b", fontWeight: 500 }}>{organizations.length} Companies</span>
            </div>
          </div>
        </div>
      </div>

      {/* ─── Company Selector + Header ─── */}
      <div style={{ maxWidth: 1280, margin: "0 auto", marginBottom: 20 }}>
        <div style={{ ...glass.card, padding: "20px 28px" }}>
          <div style={{ display: "flex", gap: 8, marginBottom: 16, flexWrap: "wrap" }}>
            {organizations.map(o => (
              <button key={o.id} onClick={() => selectOrganization(o.id)} style={{
                padding: "7px 16px", border: "none", borderRadius: 10, fontSize: 12,
                fontWeight: selectedOrgId === o.id ? 700 : 500, cursor: "pointer",
                color: selectedOrgId === o.id ? "white" : "#64748b",
                background: selectedOrgId === o.id ? `linear-gradient(135deg, ${TEAL}, ${TEAL_DARK})` : glass.button.background,
                boxShadow: selectedOrgId === o.id ? `0 3px 12px ${TEAL}40` : glass.button.boxShadow,
                transition: "all 0.25s ease",
              }}>
                {o.name}
                {o.ticker && <span style={{ opacity: 0.7, marginLeft: 4, fontSize: 10 }}>({o.ticker})</span>}
              </button>
            ))}
          </div>
          {org && (
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <div>
                <div style={{ display: "flex", alignItems: "center", gap: 16, marginBottom: 8 }}>
                  <h2 style={{ fontSize: 26, fontWeight: 800, color: "#0f172a", margin: 0 }}>{org.name}</h2>
                  <StanceBadge stance={stance} />
                </div>
                <p style={{ fontSize: 13, color: "#64748b", margin: 0 }}>
                  {org.industry} · {org.business_layer} Layer{org.ticker ? ` · ${org.ticker}` : " · Private"}
                </p>
              </div>
              <div style={{ textAlign: "right" }}>
                <div style={{ fontSize: 11, color: "#94a3b8", marginBottom: 4, fontWeight: 500 }}>Confidence</div>
                <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                  <div style={{ ...glass.pressed, width: 100, height: 8, borderRadius: 4, overflow: "hidden", padding: 0, border: "none" }}>
                    <div style={{ height: "100%", borderRadius: 4, width: `${confidence * 100}%`, background: confidence >= 0.6 ? `linear-gradient(90deg, ${TEAL_DARK}, ${TEAL})` : `linear-gradient(90deg, #D97706, #F59E0B)` }} />
                  </div>
                  <span style={{ fontSize: 16, fontWeight: 700, color: confidence >= 0.6 ? TEAL : "#F59E0B" }}>{(confidence * 100).toFixed(0)}%</span>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* ─── Main Grid ─── */}
      <div style={{ maxWidth: 1280, margin: "0 auto", display: "grid", gridTemplateColumns: "1fr 340px", gap: 20 }}>
        <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>

          {/* Radar + Scores */}
          <div style={{ ...glass.card, padding: "24px" }}>
            <h3 style={{ fontSize: 15, fontWeight: 700, color: "#1e293b", margin: "0 0 4px 0" }}>8-Axis Partnership Evaluation</h3>
            <p style={{ fontSize: 11, color: "#94a3b8", margin: "0 0 16px 0" }}>슬라이더 가중치 반영 · 외곽: 10점</p>
            <div style={{ display: "flex", gap: 20, alignItems: "center" }}>
              <div style={{ flex: 1, height: 320 }}>
                <ResponsiveContainer width="100%" height="100%">
                  <RadarChart data={radarData} cx="50%" cy="50%" outerRadius="75%">
                    <PolarGrid stroke="#cbd5e1" strokeWidth={0.5} />
                    <PolarAngleAxis dataKey="axis" tick={{ fontSize: 10, fill: "#64748b", fontWeight: 500 }} />
                    <PolarRadiusAxis angle={90} domain={[0, 10]} tick={{ fontSize: 9, fill: "#94a3b8" }} />
                    <Radar name="Score" dataKey="score" stroke={TEAL} fill={TEAL} fillOpacity={0.15} strokeWidth={2} dot={<CustomDot />} />
                    <Tooltip contentStyle={{ ...glass.card, padding: "8px 14px", fontSize: 12, border: "none" }} />
                  </RadarChart>
                </ResponsiveContainer>
              </div>
              <div style={{ width: 220 }}>
                {scores.map(s => <AxisBar key={s.dimensionKey} score={s} weight={weights[s.dimensionKey] || 1} />)}
              </div>
            </div>
          </div>

          {/* Signals */}
          <div style={{ ...glass.card, padding: "20px" }}>
            <button onClick={() => setShowSignals(!showSignals)} style={{ background: "none", border: "none", cursor: "pointer", display: "flex", alignItems: "center", gap: 8, width: "100%", padding: 0, marginBottom: showSignals ? 12 : 0 }}>
              <Activity size={16} color={TEAL} strokeWidth={2.5} />
              <span style={{ fontSize: 14, fontWeight: 700, color: "#1e293b", flex: 1, textAlign: "left" }}>Recent Signals</span>
              <span style={{ fontSize: 10, fontWeight: 600, color: TEAL, padding: "2px 8px", background: "rgba(0,163,155,0.08)", borderRadius: 4 }}>{signals.length}</span>
              {showSignals ? <ChevronUp size={14} color="#94a3b8" /> : <ChevronDown size={14} color="#94a3b8" />}
            </button>
            {showSignals && signals.length > 0 && signals.map(s => <SignalCard key={s.id} signal={s} />)}
            {showSignals && signals.length === 0 && <p style={{ fontSize: 12, color: "#94a3b8", margin: 0 }}>수집된 최근 신호가 없습니다. TINA Signal Engine 수집 후 표시됩니다.</p>}
          </div>
        </div>

        {/* ─── RIGHT: Simulation ─── */}
        <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
          <div style={{ ...glass.card, padding: "20px" }}>
            <h3 style={{ fontSize: 14, fontWeight: 700, color: "#1e293b", margin: "0 0 12px 0" }}>Weight Simulation</h3>
            <div style={{ display: "flex", flexWrap: "wrap", gap: 6, marginBottom: 16 }}>
              {presets.map(p => (
                <button key={p.name} onClick={() => handlePreset(p.name)} style={{
                  padding: "5px 12px", border: "none", borderRadius: 8, fontSize: 11, fontWeight: 600, cursor: "pointer",
                  color: activePreset === p.name ? "white" : "#64748b",
                  background: activePreset === p.name ? `linear-gradient(135deg, ${TEAL}, ${TEAL_DARK})` : "rgba(255,255,255,0.6)",
                  boxShadow: activePreset === p.name ? `0 3px 10px ${TEAL}40` : glass.button.boxShadow,
                  transition: "all 0.25s ease",
                }}>{p.name}</button>
              ))}
              {activePreset === "Custom" && <span style={{ fontSize: 11, color: "#F59E0B", fontWeight: 600, display: "flex", alignItems: "center", gap: 4 }}><RotateCcw size={11} /> Custom</span>}
            </div>
            {scores.map(s => <SliderControl key={s.dimensionKey} label={s.shortName} value={weights[s.dimensionKey] || 1} onChange={v => updateWeight(s.dimensionKey, v)} />)}
          </div>

          {/* ★ CHANGED: Stance card now shows weighted average number */}
          <div style={{ ...glass.card, padding: "20px", background: `linear-gradient(135deg, rgba(255,255,255,0.6), ${stanceConfig.bg})` }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 8 }}>
              <span style={{ fontSize: 11, color: "#94a3b8", fontWeight: 500 }}>Current Stance</span>
              <span style={{ fontSize: 22, fontWeight: 800, color: stanceConfig.color }}>{weightedAvg > 0 ? weightedAvg.toFixed(1) : "—"}</span>
            </div>
            <StanceBadge stance={stance} />
            <p style={{ fontSize: 12, color: "#475569", lineHeight: 1.6, marginTop: 12, marginBottom: 0 }}>{STANCE_DESC[stance]}</p>
          </div>

          <div style={{ ...glass.card, padding: "20px" }}>
            <div style={{ fontSize: 11, color: "#94a3b8", fontWeight: 500, marginBottom: 8 }}>Recommended Engagement</div>
            <div style={{ ...glass.cardInner, padding: "12px 16px" }}>
              <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                <ArrowRight size={14} color={TEAL} />
                <span style={{ fontSize: 13, fontWeight: 700, color: "#1e293b" }}>{ENG_MODEL[stance]}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div style={{ maxWidth: 1280, margin: "24px auto 0", textAlign: "center" }}>
        <p style={{ fontSize: 10, color: "#94a3b8" }}>SPITFIRE · KT Internal Use Only · Powered by TINA Signal Engine + Azure OpenAI</p>
      </div>
    </div>
  );
}
